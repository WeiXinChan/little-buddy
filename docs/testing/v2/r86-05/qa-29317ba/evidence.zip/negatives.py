from pathlib import Path
import subprocess,sys
for case in ['borrow','scope','expiry','recovery']:
 with Path(__file__).with_name(case+'-negative.log').open('w') as o:
  result=subprocess.run([sys.executable,'scripts/v2-parent-tests.py','--binding-mutant='+case],stdout=o,stderr=subprocess.STDOUT)
 print(case+' wrapper exit='+str(result.returncode),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
