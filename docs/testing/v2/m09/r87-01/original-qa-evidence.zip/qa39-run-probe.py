import importlib.util, pathlib, subprocess, os, json
root=pathlib.Path(__file__).resolve().parent
repo=root/'m09-qa'
spec=importlib.util.spec_from_file_location('m09script',repo/'scripts/test-m09-core.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
compiler=[m.jar('org.jetbrains.kotlin',n,v) for n,v in [('kotlin-compiler-embeddable','2.2.21'),('kotlin-stdlib','2.2.21'),('kotlin-script-runtime','2.2.21'),('kotlin-reflect','1.6.10'),('kotlin-daemon-embeddable','2.2.21')]]
compiler += [m.jar('org.jetbrains.kotlinx','kotlinx-coroutines-core-jvm','1.8.0'),m.jar('org.jetbrains','annotations','23.0.0')]
runtime=[m.jar('org.jetbrains.kotlin','kotlin-stdlib','2.2.21'),m.jar('junit','junit','4.13.2'),m.jar('org.hamcrest','hamcrest-core','1.3')]
android='/home/ubuntu/.gradle/caches/8.13/transforms/9ec1aa52f1567b6bf359cfb66d138a5b/transformed/android.jar'
out=root/'qa39-classes';out.mkdir(exist_ok=True)
sources=sorted((repo/'app/src/main/java/com/littlebuddy/v2/feedback').glob('*.kt'))
cmd=['java','-Xmx768m','-cp',os.pathsep.join(compiler),'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-jvm-target','17','-classpath',os.pathsep.join(runtime+[android]),'-d',str(out)]+list(map(str,sources))+[str(root/'qa39-probe.kt')]
p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
print('COMPILE_WITH_ANDROID_JAR',p.returncode,flush=True);print(p.stdout,flush=True)
if p.returncode:raise SystemExit(p.returncode)
p=subprocess.run(['java','-Xmx256m','-cp',os.pathsep.join([str(out)]+runtime),'org.junit.runner.JUnitCore','com.littlebuddy.v2.feedback.Review39Probe'],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
print(p.stdout,flush=True)
(root/'qa39-probe-summary.json').write_text(json.dumps({'head':'34b97d44a736de303f2b015d48ed18866986b9a2','compile_exit':0,'android_jar':android,'junit_exit':p.returncode,'stdout':p.stdout},indent=2))
raise SystemExit(p.returncode)
