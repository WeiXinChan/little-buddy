# TITA-87 / PR39 独立代码复核

结论：**建议暂不合入；R87-01为合入前修复项。** 授权三层边界与现有核心大部分反例通过，但草稿选定日志副本在到期扫描后仍保留，不能以旧确认不可提交代替清理。未改作者产品代码、未合并，交root审定并由原作者修复。

## 冻结对象与方法

- PR：https://github.com/WeiXinChan/little-buddy/pull/39
- HEAD：`34b97d44a736de303f2b015d48ed18866986b9a2`
- tree：`36da2aa368bbe61d60861a182d2c716aa25ab270`
- base：`112e456ff09f619ab5929b486ed73358110ba3d5`
- 独立detached QA工作树，10个新增文件/1116行，只有4个feedback生产Kotlin文件、1个测试、4份证据文档及1个脚本，无PIN/V1/M06/manifest/workflow改动。工作树保持clean。
- 经认证CLI下载交付附件，证据包freeze与本地SHA/tree吻合；附件core-contract.md与冻结仓库字节相同；本轮编译来源哈希与作者baseline.json逐文件吻合。
- 读本任务最新描述、增量全部线程及root05:10授权契约。平台关联表为PR39 open/未合、自动完成禁用；读取时两项外部CI pending，未等待/复跑，不计通过。

## 实际验证分母

| 执行 | 尝试 | 通过/检测有效 | 失败 | 跳过 |
|---|---:|---:|---:|---:|
| 冻结源码原34项JUnit独立复跑 | 34 | 34 | 0 | 0 |
| 新增独立JUnit反例/检查 | 7 | 6 | 1 | 0 |
| 正常测试合计 | 41 | 40 | 1 | 0 |
| 5个突变负控，各编译后运行指定方法 | 5 | 5个检测有效 | 5个预期断言失败 | 0 |
| 含AndroidFeedbackVault的4个生产文件及独立测试编译 | 1次 | 1 | 0 | 0 |

正常测试与突变分母分开。34项正常命令退出0；负控脚本退出0表示检测有效，5个JUnit子进程各退出1；独立7项JUnit退出1，明确是真实失败，不是预期负控。无测试设施失败或跳过。

复现命令（在同一工作目录保留m09-qa工作树、脚本和探针）：

```sh
cd m09-qa
scripts/with-build-lock python3 scripts/test-m09-core.py --out ../qa39-baseline.json
scripts/with-build-lock python3 scripts/test-m09-core.py --negative-controls --out ../qa39-negative.json
cd ..
m09-qa/scripts/with-build-lock python3 qa39-run-probe.py
```

所有Kotlin/Java编译与测试按既有heavy.lock串行执行，编译-Xmx768m、测试-Xmx256m；未开Gradle并行构建、手机/模拟器/HDA或云服务。新增编译把AndroidFeedbackVault一起纳入，使用既有缓存android.jar；jar摘要及探针/源码摘要在qa39-manifest.json。没有声称Android KeyStore运行、APK/安装/设备兼容或全工程编译通过。

## R87-01：到期扫描遗漏草稿日志副本

位置：`app/src/main/java/com/littlebuddy/v2/feedback/FeedbackCore.kt:127`复制源日志至Draft.logs；`:143`仅在再次preview时清过期选择；`:273`的sweep仅遍历events/materials，不处理draft。submit在`:165`附近只拒绝过期token，未清除草稿副本。

可复现步骤（独立探针`expiredSelectedDraftCopyMustBeReleasedBySweep`，不改生产代码）：

1. 可信合成时钟1000ms，记录一条白名单日志，开始草稿，selectLogs并preview。
2. 证明草稿logs ByteArray非空；时间推进到1000+WEEK，主动调用产品sweep。
3. 通过只读反射检查实际活跃草稿持有的日志ByteArray，预期已空或草稿已释放，实际仍非空，独立断言失败。

这是可达内存缓存的到期保留问题，不是对已释放内存的取证猜测；仅使用合成字段，未发现或采集真实儿童内容。复制不重置出生时间、所有副本按期清理是R13/A26及本任务明确要求。现有`exactSevenDayLogExpiryAndSelectedCopyTokenExpiry`只证明过期token拒绝/再次选择无日志，不能证明未再次操作草稿时的副本释放。即使未来管理UI会在退出清草稿，独立核心已有sweep契约仍不能依赖未接入的UI补救。

建议最小修复：在系统sweep路径按已选择最早日志出生时间清零并替换Draft.logs、清preview、使revision/confirmation失效，不调用需要活跃PIN的withoutLogs公共入口（后台清理不得等待家长Grant）。保留纯说明草稿与其他未到期材料，或明确采用更保守整草稿清除策略；不得续期或清PIN/配对。补到期前1ms、等于/超过截止、已撤销授权仍能系统清理、旧token拒绝、源日志及其他问题不误清的正反例。原失败探针应不改断言在修复后通过。

## 授权、耐久性与提供者边界审查

新增独立测试使用真实临时文件、实际JVM AES-GCM和带短monitor的合成Authorizer；revoke只拿授权monitor，既测线程竞争，也查持久字节与重启结果。

| 独立检查 | 实际结果 |
|---|---|
| staging replace阻塞期间另一线程撤销submit | revoke在300ms内返回；释放后DENIED，materials密文字节不变，重启无outbox，provider接受数0 |
| 同样阻塞clear | DENIED且持久源日志保留，重启可选中原1条日志；不靠网络spy判定 |
| 本地提交完成后provider最终admission前阻塞并撤销 | provider接受数0；重启可见SEND_FAILED，这是此前合法本地事务，不误报远端已提交 |
| 合法短回调决定后、ledger写阻塞期间撤销 | 特定clear事务持久成功，重启日志为0；不把已合法决定的操作误称未执行 |
| 精确范围/字节独立oracle | 只选1000ms一条，不含1001ms条目；count=1，首尾1000，ASCII字节与provider副本逐字节一致 |
| 未知字段落盘前过滤 | 解密实际持久材料检查合成秘密哨兵缺失，不只检查密文字节找不到明文 |

protectedChange在隔离副本准备和staging IO完成后，才在accept短回调发布实际状态与一次性Committed对象；之后的写盘是特定事务履行。未发现跨staging IO缓存accepted布尔的旧问题。provider仍必须遵守admit与其接收决定原子绑定的契约；当前接口和测试不证明任何真实平台实现。核心monitor可跨IO，但不应被生命周期revoke获取，真实授权接线仍需独立复核；本轮合成Auth不替代PIN实现或真实Grant。

5项突变均编译成功，原始日志核对确实命中预期断言，非初始化/编译失败：

- later-deadline：期望172801000、实际604801000；min改max被检出。
- missing-ledger：期望QUARANTINED，变体未拒绝。
- early-grant-submit：期望DENIED，实际null（没有失败），被检出。
- early-grant-clear：同上，独立方法检出。
- incomplete-deletion：期望DELETING、实际DELETED，不能把部分删除报完成。

## 其他检查结果及保留门槛

白名单字段为枚举/固定数值，无任意异常/正文入口；说明变化、选择变化及重新preview使旧确认失效。纯说明默认无日志；1000条/256KiB/2000码点为文档标明的工程初值。源日志与问题副本的清理范围分开，测试中其他问题、独立PIN/配对哨兵文件未被删除；生产路径不访问PIN/配对。

原34项实际覆盖丢账本旧快照、材料与账本不匹配、损坏密文/错误key、发布中断重启隔离、删除失败、幂等原键/重启删除重试及迟到撤回占优。截止函数严格min(原提交+7天,首次撤回+24h)，已收到提交回执后时间不被回复/重复撤回更新；日志副本沿用源条目出生时间。真正补充/重提/分页API未开放，不能声称补充端到端验证完成。系统到期/后台清理仍需未来宿主调度，不作为本轮实测能力。

两个合法旧文件整体回滚无法被本地密码学自动辨识，作者已明确不支持该恢复途径；quarantineRestore必须由未来恢复入口强制先调用，现只有核心隔离入口测试。Android factory没有恢复入口接线，不能宣称整体回滚已解决。真实Android KeyStore/文件系统故障仍未执行；缓存jar编译只关闭“工厂语法/API未编译”这一缺口。

生产默认DenyParentAuthorizer/UnavailableFeedbackProvider，合成实现只在test。本核心没有偷偷引入已批准PIN/真实OwnerProof。D02/D06可信设备绑定、平台维护者访问、全副本删除/缓存下载备注备份、立即撤销及24h/7d实际调度证据均OPEN；管理UI/后台/语音生命周期和完整M09/A24–A31同样OPEN。不让用户补过程操作或将成人/合成测试当童声证据。

交付为本报告与原始JSON/日志、独立探针源码及运行器。建议原作者仅修R87-01后冻结新SHA交QA定向复核；root最终决定合入，未自行派单或合并。
